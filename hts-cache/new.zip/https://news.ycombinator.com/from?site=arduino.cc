<html>
<head>
  <link rel="stylesheet" type="text/css" href="/news.css">
  <link rel="shortcut icon" href="/favicon.ico">
  <title>Hacker News</title>
</head>
<body>
  <center>
    <table border="0" cellpadding="0" cellspacing="0" width="85%" bgcolor="#f6f6ef">
      <tr>
        <td bgcolor="#ff6600">
          <table border="0" cellpadding="0" cellspacing="0" width="100%" style="padding:2px">
            <tr>
              <td style="width:18px;padding-right:4px">
                <a href="http://ycombinator.com">
                  <img src="/y18.gif" width="18" height="18" style="border:1px #ffffff solid;" />
                </a>
              </td>
              <td style="line-height:12pt; height:10px;">
                <span class="pagetop"> <b><a href="/news">Hacker News</a></b> 
                </span>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr style="height:10px"></tr>
      <tr>
        <td>
          Sorry, we're not able to serve your requests this quickly.
        </td>
      </tr>
      <tr style="height:12px"></tr>
      <tr>
        <td style="font-size:9pt">
          <a href='javascript:window.location.reload();'>reload</a>
        </td>
      </tr>
      <tr style="height:2px"></tr>
      <tr>
        <td>
          <img src="s.gif" height="10" width="0" />
          <table width="100%" cellspacing="0" cellpadding="1">
            <tr>
              <td bgcolor="#ff6600"></td>
            </tr>
          </table>
          <br />
        </td>
      </tr>
    </table>
  </center>
</body>
</html>
